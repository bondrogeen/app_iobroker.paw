/*---------------------------------------------------------
  Configuration
---------------------------------------------------------*/

// Set this to the server side language you wish to use.
var lang = 'xhtml'; // options: lasso, php, py

// Set this to the directory you wish to manage.
var fileRoot = '/';

// Show image previews in grid views?
var showThumbs = true;
